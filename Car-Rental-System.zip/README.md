# Car Rental System

Java Swing application connected to MySQL for managing car rentals.