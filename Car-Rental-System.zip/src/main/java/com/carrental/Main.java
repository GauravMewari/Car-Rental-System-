package com.carrental;

import com.carrental.gui.LoginForm;

public class Main {
    public static void main(String[] args) {
        new LoginForm();
    }
}