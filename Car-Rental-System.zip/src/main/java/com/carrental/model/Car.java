package com.carrental.model;

public class Car {
    private int id;
    private String model;
    private String brand;
    private boolean available;

    // Getters and Setters
}