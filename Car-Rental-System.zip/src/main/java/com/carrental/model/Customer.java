package com.carrental.model;

public class Customer {
    private int id;
    private String name;
    private String contact;

    // Getters and Setters
}